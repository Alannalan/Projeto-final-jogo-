var x= 180
var y= 350
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
 
    if(keyIsDown(RIGHT_ARROW)){
      x=x+6
    }
  
    if(keyIsDown(LEFT_ARROW)){
      x= x -6
    }
   
    if(keyIsDown(UP_ARROW)){
     y = y - 6
    }
    
    if(keyIsDown(DOWN_ARROW)){
    y = y + 6
    }
  ellipse(x,y,40,40)
  

  rect(170,40,50,50)
  

}
